import java.util.HashMap;
import java.util.Map;

public class Estado {
    String nombre;
    boolean esFinal;
    Map<Character, Estado> transiciones;

    public Estado(String nombre, boolean esFinal) {
        this.nombre = nombre;
        this.esFinal = esFinal;
        this.transiciones = new HashMap<>();
    }
    public Estado mover(char simbolo) {
        return transiciones.get(simbolo);
    }
}