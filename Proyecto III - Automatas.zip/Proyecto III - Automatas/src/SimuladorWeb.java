import java.io.*;
import java.awt.Desktop;

public class SimuladorWeb {

    public static void main(String[] args) {
        try {
            String nombreArchivo = "index.html";

            String contenidoHTML = """
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Simulador Visual - Máquina de Turing</title>
<style>
  :root{
    --bg:#0b1220;
    --panel:#0f1724;
    --muted:#94a3b8;
    --accent:#38bdf8;
    --success:#16a34a;
    --danger:#ef4444;
    --card:#0b1624;
    --glass: rgba(255,255,255,0.03);
  }
  *{box-sizing:border-box;font-family:Inter,ui-sans-serif,system-ui,Segoe UI,Roboto,"Helvetica Neue",Arial;}
  body{margin:0;min-height:100vh;background:linear-gradient(180deg,#071023 0%, #07182b 100%);color:#e6eef6;display:flex;align-items:flex-start;justify-content:center;padding:24px;}
  .wrap{width:100%;max-width:1100px;}
  header{display:flex;align-items:center;gap:16px;margin-bottom:18px}
  h1{margin:0;font-size:20px;color:var(--accent)}
  .controls{display:flex;gap:12px;align-items:center;margin-bottom:14px;flex-wrap:wrap}
  input[type=file],input[type=text]{background:var(--card);color:var(--muted);padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,0.03)}
  select, button{padding:8px 12px;border-radius:8px;border:1px solid rgba(255,255,255,0.06);background:var(--panel);color:inherit}
  button{cursor:pointer;background:var(--accent);color:#032; font-weight:600;border:none;}
  button:disabled{opacity:0.5;cursor:not-allowed}
  main{display:grid;grid-template-columns:340px 1fr;gap:16px;}
  .panel{background:linear-gradient(180deg,rgba(255,255,255,0.02),var(--glass));padding:14px;border-radius:12px;border:1px solid rgba(255,255,255,0.03)}
  .panel h2{margin:0 0 8px 0;font-size:14px;color:var(--muted)}
  .list{max-height:420px;overflow:auto;padding-top:6px}
  .item{padding:8px;border-radius:8px;margin-bottom:6px;background:transparent;border:1px dashed rgba(255,255,255,0.02);cursor:pointer}
  .item.selected{background:linear-gradient(90deg, rgba(56,189,248,0.08), rgba(16,185,129,0.02));border:1px solid rgba(56,189,248,0.12)}
  .stage{display:flex;flex-direction:column;gap:12px}
  .visual{background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));padding:14px;border-radius:12px;min-height:260px;position:relative;overflow:hidden}
  .tape{display:flex;gap:8px;align-items:flex-end;height:80px;justify-content:center;margin-top:8px}
  .cell{width:48px;height:56px;border-radius:6px;border:2px solid rgba(255,255,255,0.04);display:flex;align-items:center;justify-content:center;background:#07182b;font-size:20px}
  .head{
    position:absolute;
    top:86px;
    font-size:28px;
    color:var(--accent);
    transition: left 0.4s cubic-bezier(.2,.8,.2,1);
  }
  .head2{
    position:absolute;
    top:186px;
    font-size:28px;
    color:var(--success);
    transition: left 0.4s cubic-bezier(.2,.8,.2,1);
  }
  .estadoBox{padding:10px;border-radius:8px;background:#061226;border:1px solid rgba(255,255,255,0.03);display:flex;align-items:center;gap:10px}
  .estadoBox .dot{width:12px;height:12px;border-radius:50%;background:var(--accent)}
  .result{padding:10px;border-radius:8px;font-weight:700}
  .accepted{background:linear-gradient(90deg, rgba(22,163,74,0.12), rgba(22,163,74,0.05));color:var(--success);border:1px solid rgba(22,163,74,0.12)}
  .rejected{background:linear-gradient(90deg, rgba(239,68,68,0.08), rgba(239,68,68,0.03));color:var(--danger);border:1px solid rgba(239,68,68,0.08)}
  .small{font-size:13px;color:var(--muted)}
  footer{margin-top:12px;text-align:center;color:var(--muted);font-size:13px}
  #log{max-height:160px;overflow:auto;font-size:13px;background:rgba(255,255,255,0.03);padding:6px;border-radius:8px;}
</style>
</head>
<body>
  <div class="wrap">
    <header>
      <h1>Máquina de Turing</h1>
    </header>
    <div class="controls">
      <input id="fileInput" type="file" accept=".txt" />
      <button id="loadBtn" disabled>Cargar archivo</button>
      <input id="cadenaInput" type="text" placeholder="Ingrese cadena a evaluar" style="flex:1;"/>
      <button id="simulateBtn" disabled>Simular expresión</button>
    </div>
    <main>
      <aside class="panel">
        <h2>Expresiones (input.txt)</h2>
        <div class="list" id="exprList">
          <div class="small">Sube un archivo .txt con una expresión por línea y selecciona una.</div>
        </div>
      </aside>
      <section class="panel stage">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div>
            <div class="small">Expresión seleccionada:</div>
            <div id="selectedExpr" style="font-weight:700;margin-top:6px">—</div>
          </div>
          <div class="estadoBox">
            <div class="dot"></div><div id="estadoText">q0</div>
          </div>
        </div>
        <div class="visual" id="visualArea">
          <div style="text-align:center" class="small">Cinta 1 (entrada)</div>
          <div class="tape" id="tape1"></div>
          <div class="head" id="head1">⬆</div>
          <div style="text-align:center;margin-top:20px" class="small">Cinta 2 (trabajo)</div>
          <div class="tape" id="tape2"></div>
          <div class="head2" id="head2">⬆</div>
        </div>
        <div id="finalResult"></div>
        <div id="log"></div>
      </section>
    </main>
    <footer>Simulación visual paso a paso de una máquina de Turing que evalúa expresiones regulares.</footer>
  </div>

<script>
let expressions = [];
let selectedExpr = '';
let currentState = 'q0';
let step = 0;

const fileInput = document.getElementById('fileInput');
const loadBtn = document.getElementById('loadBtn');
const simulateBtn = document.getElementById('simulateBtn');
const exprList = document.getElementById('exprList');
const selectedExprDiv = document.getElementById('selectedExpr');
const tape1Div = document.getElementById('tape1');
const tape2Div = document.getElementById('tape2');
const head1 = document.getElementById('head1');
const head2 = document.getElementById('head2');
const estadoText = document.getElementById('estadoText');
const finalResult = document.getElementById('finalResult');
const cadenaInput = document.getElementById('cadenaInput');
const logDiv = document.getElementById('log');

fileInput.addEventListener('change', () => {
  loadBtn.disabled = !fileInput.files.length;
});

loadBtn.addEventListener('click', async () => {
  const file = fileInput.files[0];
  if (!file) return;
  const text = await file.text();
  expressions = text.split(/\\r?\\n/).filter(l => l.trim().length > 0);
  renderList();
});

function renderList(){
  exprList.innerHTML = '';
  expressions.forEach((expr, i) => {
    const div = document.createElement('div');
    div.textContent = expr;
    div.className = 'item';
    div.onclick = () => selectExpr(i);
    exprList.appendChild(div);
  });
}

function selectExpr(i){
  document.querySelectorAll('.item').forEach(e=>e.classList.remove('selected'));
  const el = exprList.children[i];
  el.classList.add('selected');
  selectedExpr = expressions[i];
  selectedExprDiv.textContent = selectedExpr;
  simulateBtn.disabled = false;
}

simulateBtn.addEventListener('click', () => simulate());

async function simulate(){
  const regexStr = selectedExpr.trim();
  const inputStr = cadenaInput.value.trim();

  if (!inputStr){
    alert('Ingrese una cadena para evaluar.');
    return;
  }

  const tape1 = inputStr.split('');
  const tape2 = Array(tape1.length).fill('_');

  tape1Div.innerHTML = '';
  tape2Div.innerHTML = '';
  logDiv.innerHTML = '';
  finalResult.innerHTML = '';
  step = 0;
  currentState = 'q0';
  estadoText.textContent = currentState;

  for(let i=0; i<tape1.length; i++){
    let c1 = document.createElement('div');
    c1.className = 'cell';
    c1.textContent = tape1[i];
    tape1Div.appendChild(c1);

    let c2 = document.createElement('div');
    c2.className = 'cell';
    c2.textContent = tape2[i];
    tape2Div.appendChild(c2);
  }

  const cells1 = document.querySelectorAll('#tape1 .cell');
  const cells2 = document.querySelectorAll('#tape2 .cell');

  positionHeadOver(head1, cells1[0], tape1Div);
  positionHeadOver(head2, cells2[0], tape2Div);

  let accepted = false;
  try {
    const re = new RegExp('^' + regexStr + '$');
    accepted = re.test(inputStr);
  } catch(e){
    log('Error: expresión regular inválida.');
    estadoText.textContent = 'qE';
    finalResult.innerHTML = '<div class="result rejected">RECHAZADA</div>';
    return;
  }

  for(let i=0; i<tape1.length; i++){
    step++;
    currentState = 'q' + step;
    estadoText.textContent = currentState;
    positionHeadOver(head1, cells1[i], tape1Div);
    animateHead(head1);
    log(`Leyendo símbolo '${tape1[i]}' en cinta 1 → copia a cinta 2, estado ${currentState}`);
    tape2[i] = tape1[i];
    cells2[i].textContent = tape2[i];
    positionHeadOver(head2, cells2[i], tape2Div);
    animateHead(head2);
    await new Promise(r => setTimeout(r, 500));
  }

  const estadoFinal = 'q' + tape1.length;
  estadoText.textContent = estadoFinal;

  if (accepted){
    finalResult.innerHTML = `<div class="result accepted">ACEPTADA (Estado final: ${estadoFinal})</div>`;
    log('La cadena coincide con la expresión ✓');
  } else {
    finalResult.innerHTML = `<div class="result rejected">RECHAZADA (Estado final: ${estadoFinal})</div>`;
    log('La cadena NO coincide con la expresión ✗');
  }
}

function positionHeadOver(head, cell, tapeDiv){
  const tapeRect = tapeDiv.getBoundingClientRect();
  const cellRect = cell.getBoundingClientRect();
  const centerX = cellRect.left - tapeRect.left + cellRect.width / 2;
  head.style.left = (centerX - head.offsetWidth / 2) + 'px';
}

function animateHead(head){
  head.style.transform = 'translateY(-10px)';
  setTimeout(()=> head.style.transform = 'translateY(0)', 200);
}

function log(msg){
  const p = document.createElement('div');
  p.textContent = msg;
  logDiv.appendChild(p);
  logDiv.scrollTop = logDiv.scrollHeight;
}
</script>
</body>
</html>
""";

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
                writer.write(contenidoHTML);
            }

            System.out.println("Archivo index.html generado correctamente.");
            File archivo = new File(nombreArchivo);
            if (archivo.exists()) {
                Desktop.getDesktop().browse(archivo.toURI());
                System.out.println("Abriendo en el navegador...");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}