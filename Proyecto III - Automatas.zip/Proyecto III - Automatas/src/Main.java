import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        List<String> expresiones = leerExpresiones("input.txt");
        boolean salir = false;

        while (!salir) {
            System.out.println("=== EXPRESIONES DISPONIBLES ===");
            for (int i = 0; i < expresiones.size(); i++)
                System.out.println((i + 1) + ". " + expresiones.get(i));

            System.out.print("Elige una expresión (número): ");
            int opcion = sc.nextInt();
            sc.nextLine();

            String expresion = expresiones.get(opcion - 1);
            System.out.println("\nSeleccionaste: " + expresion);

            boolean continuar = true;
            while (continuar) {
                System.out.print("\nIngresa una cadena para evaluar: ");
                String cadena = sc.nextLine();

                evaluarExpresion(expresion, cadena);

                System.out.println("\n¿Qué desea hacer ahora?");
                System.out.println("1. Evaluar otra cadena con la misma expresión regular");
                System.out.println("2. Seleccionar otra expresión regular");
                System.out.println("3. Salir");
                System.out.print("Seleccione una opción: ");

                int respuesta = sc.nextInt();
                sc.nextLine();

                switch (respuesta) {
                    case 1:
                        continuar = true;
                        break;
                    case 2:
                        continuar = false;
                        break;
                    case 3:
                        continuar = false;
                        salir = true;
                        break;
                    default:
                        System.out.println("Opción no válida. Regresando al menú principal...");
                        continuar = false;
                        break;
                }
            }
        }

        sc.close();
        System.out.println("\nPrograma finalizado.");
    }

    private static List<String> leerExpresiones(String ruta) throws IOException {
        List<String> lineas = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(ruta));
        String linea;
        while ((linea = br.readLine()) != null)
            if (!linea.trim().isEmpty()) lineas.add(linea.trim());
        br.close();
        return lineas;
    }

    private static void evaluarExpresion(String expresion, String cadena) throws InterruptedException {
        System.out.println("\n--- Simulación de Máquina de Turing ---");
        System.out.println("Expresión: " + expresion);
        System.out.println("Cadena: " + cadena);
        System.out.println("----------------------------------------");

        char[] cinta = cadena.toCharArray();
        int cabezal = 0;

        for (int paso = 1; paso <= cinta.length; paso++) {
            System.out.println("Paso " + paso + ":");
            imprimirCinta(cinta, cabezal);
            System.out.println("Estado actual: q" + paso);

            // Movimiento del cabezal
            String movimiento;
            if (paso < cinta.length) {
                movimiento = "→ (mover a la derecha)";
                cabezal++;
            } else {
                movimiento = "(detenerse)";
            }

            System.out.println("Movimiento: " + movimiento);
            Thread.sleep(500);
            System.out.println();
        }

        boolean aceptada = false;
        String razon = "";

        try {
            Pattern pattern = Pattern.compile(expresion);
            Matcher matcher = pattern.matcher(cadena);
            aceptada = matcher.matches();

            if (!aceptada) {
                if (cadena.isEmpty()) {
                    razon = "La cadena está vacía.";
                } else if (!cadena.matches(".*[a-zA-Z0-9].*")) {
                    razon = "La cadena contiene caracteres no válidos.";
                } else {
                    razon = "La cadena no cumple con el patrón de la expresión regular.";
                }
            }

        } catch (PatternSyntaxException e) {
            razon = "La expresión regular tiene un error de sintaxis.";
        }

        System.out.println("=== RESULTADO FINAL ===");
        System.out.println("Expresión: " + expresion);
        System.out.println("Cadena: " + cadena);
        if (aceptada) {
            System.out.println("Resultado: Aceptada");
        } else {
            System.out.println("Resultado: Rechazada");
            System.out.println("Motivo: " + razon);
        }
    }

    private static void imprimirCinta(char[] cinta, int cabezal) {
        System.out.print("Cinta: [");
        for (int i = 0; i < cinta.length; i++) {
            System.out.print(cinta[i]);
            if (i < cinta.length - 1) System.out.print(", ");
        }
        System.out.println("]");
        for (int i = 0; i < (8 + cabezal * 3); i++) System.out.print(" ");
        System.out.println("^ (Cabezal)");
    }
}