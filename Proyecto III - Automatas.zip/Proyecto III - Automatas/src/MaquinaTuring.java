import java.util.*;

public class MaquinaTuring {
    private Estado estadoInicial;
    private Set<Estado> estados;
    private Estado estadoActual;

    public MaquinaTuring(Estado estadoInicial, Set<Estado> estados) {
        this.estadoInicial = estadoInicial;
        this.estados = estados;
    }

    public boolean evaluarCadena(String expresion, String cadena) throws InterruptedException {
        estadoActual = estadoInicial;
        char[] cinta = cadena.toCharArray();
        int cabezal = 0;
        int paso = 1;
        boolean aceptada = false;

        System.out.println("\n--- Simulación de Máquina de Turing ---");
        System.out.println("Expresión: " + expresion);
        System.out.println("Cadena: " + cadena);
        System.out.println("----------------------------------------");

        while (cabezal >= 0 && cabezal < cinta.length) {
            System.out.println("Paso " + paso + ":");
            imprimirCinta(cinta, cabezal);
            System.out.println("Estado actual: " + estadoActual.nombre);
            Thread.sleep(500);

            Estado siguiente = estadoActual.mover(cinta[cabezal]);

            if (siguiente == null) {
                System.out.println("Movimiento: (Sin transición, se detiene)");
                break;
            }

            // Movimiento simulado según nombre de estado
            String movimiento;
            if (siguiente.nombre.compareTo(estadoActual.nombre) > 0) {
                movimiento = "→";
                cabezal++;
            } else if (siguiente.nombre.compareTo(estadoActual.nombre) < 0) {
                movimiento = "←";
                cabezal = Math.max(0, cabezal - 1);
            } else {
                movimiento = "";
            }

            System.out.println("Movimiento: " + movimiento + "\n");
            estadoActual = siguiente;
            paso++;
        }

        if (estadoActual.esFinal) aceptada = true;

        System.out.println("\n=== RESULTADO FINAL ===");
        System.out.println("Expresión: " + expresion);
        System.out.println("Cadena: " + cadena);
        System.out.println("Estado final: " + estadoActual.nombre);
        System.out.println("Resultado: " + (aceptada ? "Aceptada" : "Rechazada"));

        return aceptada;
    }

    private void imprimirCinta(char[] cinta, int cabezal) {
        System.out.print("Cinta: [");
        for (int i = 0; i < cinta.length; i++) {
            System.out.print(cinta[i]);
            if (i < cinta.length - 1) System.out.print(", ");
        }
        System.out.println("]");
        for (int i = 0; i < (8 + cabezal * 3); i++) System.out.print(" ");
        System.out.println("^ (Cabezal)");
    }
}